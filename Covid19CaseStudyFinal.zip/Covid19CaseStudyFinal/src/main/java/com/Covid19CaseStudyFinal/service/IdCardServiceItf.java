package com.Covid19CaseStudyFinal.service;

import org.springframework.stereotype.Component;

import com.Covid19CaseStudyFinal.entity.IdCard;

@Component
public interface IdCardServiceItf {
	public IdCard addIdCard (IdCard idcard);
	public IdCard getPanCardByNumber(Integer panNo);
	public IdCard getAdharCardByNo(Integer adharno);

}
