package com.Covid19CaseStudyFinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Covid19CaseStudyFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
